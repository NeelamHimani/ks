package Pages;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentReports;

import Test.ConstantVariables;

public class LoginPage {

	
	static String username;
	static String Password;
	static String loginbutton;
	static String InvalidLogin;
	
	static WebElement username1;
	static WebElement password;
	
	public static void main(String args[]) throws IOException {
		fileUpload();
	}
	
	public static void loginPage() throws Exception {

		KSPH_Login_Page.getfile(
				"C:\\project\\15-07-2020\\KSPH_Automation_Script\\src\\test\\java\\ExcelData\\Login_Xpath.xlsx");

		if (KSPH_Login_Page.getExcelData(1, 1, 1) == null || KSPH_Login_Page.getExcelData(1, 2, 1) == null) {

			System.out.println("data is not available");

		} else {

			username = KSPH_Login_Page.getExcelData(1, 1, 2);
			if (username != null) {
				System.out.println(username);
				username1 = ConstantVariables.driver.findElement(By.xpath(username));
			}

			Password = KSPH_Login_Page.getExcelData(1, 2, 2);
			if (Password != null) {
				password = ConstantVariables.driver.findElement(By.xpath(Password));
			}

			InvalidLogin = KSPH_Login_Page.getExcelData(1, 4, 2);
			if (InvalidLogin != null) {
				System.out.println(InvalidLogin);
			}

			loginbutton = KSPH_Login_Page.getExcelData(1, 3, 2);
			WebElement login = ConstantVariables.driver.findElement(By.xpath(loginbutton));

			String filePath = ConstantVariables.TestDataFile;
			FileInputStream fis = new FileInputStream(filePath); // Your .xlsx file name along with path
			ConstantVariables.excelWorkbook = new XSSFWorkbook(fis);
			ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheet("TestData");
			System.out.println("Excel sheet name====" + ConstantVariables.excelSheet.getSheetName());
			// Find number of rows in excel file
			int rowCount = ConstantVariables.excelSheet.getLastRowNum() - ConstantVariables.excelSheet.getFirstRowNum();
			// Create a loop over all the rows of excel file to read it
			int count = ConstantVariables.excelSheet.getPhysicalNumberOfRows();
			for (int i = 1; i < count; i++) {

				Row row1 = ConstantVariables.excelSheet.getRow(i);
				username1.clear();
				password.clear();
				String username = row1.getCell(4).getStringCellValue();
				username1.sendKeys(username);
				String password1 = row1.getCell(5).getStringCellValue();
				password.sendKeys(password1);

				login.click();

				Thread.sleep(1500L);

				/*
				 * Code for display the result value in TestData File. Use the assert true and
				 * assert false value and change the value as per the validation message
				 */
				 
				boolean isFound = existsElement(By.xpath(InvalidLogin));
				System.out.println(username);
				System.out.println(password1);
				if (isFound) {
					System.out.println(" displayed as fail it as fail");
					
					String ActualMessage = ConstantVariables.driver.findElement(By.xpath(InvalidLogin)).getText();
					System.out.println(
							"===================================================================" + ActualMessage);
					try {
						if (ActualMessage != null) {
						//	String expectedMessage = "Please enter valid username.";
						//	Assert.assertTrue("Please enter valid username.", expectedMessage.equals(ActualMessage));
						//	System.out.println("Test Pass");
							ExcelUtil.setCellData("PASS", i, 6);	
							
						}else {
							String expectedMessageValidation = "Invalid username an";
							Assert.assertFalse("Invalid username an", expectedMessageValidation.equals(ActualMessage));
							System.out.println("Test Fail");
							ExcelUtil.setCellData("Fail", i, 6);
						}
					}catch (NullPointerException e) {
						e.printStackTrace();
						System.out.println(e.getMessage());
					}
					
				} else {
					System.out.println("tag it as passed in excel.");
					ExcelUtil.setCellData("PASS", i, 6);
				}
			}
		}
	}
		  
	public static void fileUpload() throws IOException {
		
		KSPH_Login_Page.getfile(ConstantVariables.ORFile);

		ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheetAt(0);
		System.out.println(ConstantVariables.excelSheet.getSheetName());

		String path = System.getProperty("user.dir") + "//Reports//KSPH_Automation_Script.html";
		System.out.println("path value=====" + path);
		ConstantVariables.report = new ExtentReports(path);

		ConstantVariables.test = ConstantVariables.report.startTest("Registration With KSPH");
		String server = ConstantVariables.excelSheet.getRow(1).getCell(1).getStringCellValue();
		System.out.println(server);

		switch (server) {
		case "Test1":
			ConstantVariables.driver.get("https://test1.kloudscript.net/kloudscript/auth/login");
			break;
		case "Test2":
			ConstantVariables.driver.get("https://test2.kloudscript.net/kloudscript/auth/login");
			break;
		case "Test3":
			ConstantVariables.driver.get("https://test3.kloudscript.net/kloudscript/auth/login");
			break;
		case "UAT100":
			ConstantVariables.driver.get("https://uat100.kloudscript.net:100/kloudscript/auth/login");
			break;
		case "UAT251":
			ConstantVariables.driver.get("https://uat251.kloudscript.net:251/kloudscript/auth/login");
			break;
		case "Ketu":
			ConstantVariables.driver.get("https://ketu.kloudscript.net/kloudscript/auth/login");
			break;
		case "KsKetu":
			System.out.println("KsKetu");
			break;
		case "KSPH":
			ConstantVariables.driver.get("https://solutions.kloudscript.net/");
			break;
		case "dev3":
			ConstantVariables.driver.get("https://dev3.kloudscript.net/");
			break;
		default:
			System.out.println("Not able to Find the Server");
			break;
		}

		String currentURL = ConstantVariables.driver.getCurrentUrl();
		System.out.println("currentURL==========" + currentURL);

		String pageTitle = ConstantVariables.driver.getTitle();
		System.out.println("pageTitle===============" + pageTitle);


		
	}

	private static boolean existsElement(By id) {
	    try {
	    	ConstantVariables.driver.findElement(id);
	    } catch (NoSuchElementException e) {
	        return false;
	    }
	    return true;
	}
	
}
