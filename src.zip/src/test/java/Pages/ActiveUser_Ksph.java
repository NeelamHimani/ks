package Pages;

import Test.ConstantVariables;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.KSPH_Login_Page;

public class ActiveUser_Ksph {

	public static void activeUser() throws IOException, InterruptedException {

		ConstantVariables.driver.get("https://test2.kloudscript.net/kloudscript/auth/login");
		
		String currentURL = ConstantVariables.driver.getCurrentUrl();
		System.out.println("currentURL==========" + currentURL);

		String pageTitle = ConstantVariables.driver.getTitle();
		System.out.println("pageTitle===============" + pageTitle);
		WebDriverWait wait = new WebDriverWait(ConstantVariables.driver, 15);
		// Code for to Redirect test2 server and active user

		// Click on KS SSO button
		KSPH_Login_Page.getfile(ConstantVariables.ORFile);

		// get sheet of ActiveuserXpath
		ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheetAt(3);
		System.out.println("SheetName======"+ConstantVariables.excelSheet.getSheetName());

		// Get Value of XPATH
		String KSSSOUserXpath = KSPH_Login_Page.getExcelData(3, 1, 2);
		String KSSSOEmailAddress = KSPH_Login_Page.getExcelData(3, 2, 2);
		String NextButtonXapth = KSPH_Login_Page.getExcelData(3, 3, 2);
		String PasswordXpath = KSPH_Login_Page.getExcelData(3, 4, 2);
		String PasswordNextButtonXpath=KSPH_Login_Page.getExcelData(3, 5, 2);
		String PortalNotificationXpath=KSPH_Login_Page.getExcelData(3, 6, 2);
		String NotificationSymbolXpath=KSPH_Login_Page.getExcelData(3, 7, 2);
		String MenuButtonXpath=KSPH_Login_Page.getExcelData(3, 8, 2);
		String ServiceRequestXpath=KSPH_Login_Page.getExcelData(3, 9, 2);
		String AccountManagementXpath=KSPH_Login_Page.getExcelData(3, 10, 2);
		String SearchWithUsernameXpath=KSPH_Login_Page.getExcelData(3, 11, 2);
		String SearchButtonXpath=KSPH_Login_Page.getExcelData(3, 12, 2);
		String MenuButtonClickXpath=KSPH_Login_Page.getExcelData(3, 16, 2);
		String SubscriptionButtonXpath=KSPH_Login_Page.getExcelData(3, 17, 2);
		String SearchSubscriptionUsernameXpath=KSPH_Login_Page.getExcelData(3, 18, 2);
		String SubscriptionSearchButtonXpath=KSPH_Login_Page.getExcelData(3, 19, 2);
		String SubscriptionApproveButtonXpath=KSPH_Login_Page.getExcelData(3, 20, 2);
		String ClickOnYesButtonXpath=KSPH_Login_Page.getExcelData(3, 21, 2);
		String MSAMenuXpath=KSPH_Login_Page.getExcelData(3, 24, 2);
		String MSAManagementXpath=KSPH_Login_Page.getExcelData(3, 25, 2);
		String MSASearchByUsernameXpath=KSPH_Login_Page.getExcelData(3, 26, 2);
		String MSASearchButtonXpath=KSPH_Login_Page.getExcelData(3, 27, 2);
		String MSASignatureButtonXpath=KSPH_Login_Page.getExcelData(3, 28, 2);
		String MSASignatureCanvasXpath=KSPH_Login_Page.getExcelData(3, 29, 2);
		String MSASignButtonXpath=KSPH_Login_Page.getExcelData(3, 30, 2);
		
	//	String ActiveButtonXpath=KSPH_Login_Page.getExcelData(3, 13, 2);
	//	String ClickYesButtonXpath=KSPH_Login_Page.getExcelData(3, 14, 2);
		
		// Variable of WebElement
		WebElement KSSSOLoginButton;
		WebElement EmailAddress;
		WebElement NextButtonelement;
		WebElement PasswordElement;
		WebElement PasswordNextButtonelement;
		WebElement PortalNotificationElement;
		WebElement NotificationSymbolElement;
		WebElement MenuButtonElement;
		WebElement ServiceElement;
		WebElement AccountmanagementElement;
		WebElement SearchWithUsername;
		WebElement SearchButtonElement;
		WebElement ActiveUserElement;
		WebElement ClickYesButtonElement;
		WebElement ClickMenuButtonElement;
		WebElement SubscriptinButtonElement;
		WebElement SearchSubscriptionUsenameElement;
		WebElement SubscriptionSearchButtonElement;
		WebElement SubscriptionApproveButtonElement;
		WebElement ClickOnYesButtonWebElement;
		WebElement MSAMenuElement;
		WebElement MSAManagementElement;
		WebElement MSASearchByUsernameElement;
		WebElement MSASearchButtonElement;
		WebElement MSASignatureElement;
		WebElement MSASignatureCanvasElement;
		WebElement MSASignButtonElement;
		
		// Code For TestData File
		String filePath = ConstantVariables.TestDataFile;
		FileInputStream fis = new FileInputStream(filePath); // Your .xlsx file name along with path
		ConstantVariables.excelWorkbook = new XSSFWorkbook(fis);
		ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheet("ActiveUserData");
		System.out.println("Excel sheet name====" + ConstantVariables.excelSheet.getSheetName());
		
		KSSSOLoginButton = ConstantVariables.driver.findElement(By.xpath(KSSSOUserXpath));
		KSSSOLoginButton.click();

		// Get Value of TestData File
		String EmailAddressValue = KSPH_Login_Page.getExcelData(2, 1, 4);
		System.out.println("EmailAddressValue======="+EmailAddressValue);
		String PasswordFieldValue = KSPH_Login_Page.getExcelData(2, 1, 5);
		System.out.println("PasswordFieldValue======="+PasswordFieldValue);
		String SearchFieldValue=KSPH_Login_Page.getExcelData(2, 1, 6);
		System.out.println("SearchFieldValue======="+SearchFieldValue);
		

		String winHandleBefore = ConstantVariables.driver.getWindowHandle();
		for (String winHandle : ConstantVariables.driver.getWindowHandles()) {
			ConstantVariables.driver.switchTo().window(winHandle);

		}
		

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(KSSSOEmailAddress)));
		
		WebElement UserEmail = ConstantVariables.driver.findElement(By.xpath(KSSSOEmailAddress));
		UserEmail.clear();
		UserEmail.sendKeys(EmailAddressValue);
		
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(NextButtonXapth)));
		ConstantVariables.driver.findElement(By.xpath(NextButtonXapth)).click();

		Thread.sleep(4000);
		
		ConstantVariables.driver.manage().window().maximize();
	
//		ArrayList<String> tabs6 = new ArrayList<String>(ConstantVariables.driver.getWindowHandles());
	//	ConstantVariables.driver.switchTo().window(tabs6.get(1));
		//System.out.println("current URL=====" + ConstantVariables.driver.getCurrentUrl());
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PasswordXpath)));
		WebElement UserPass = ConstantVariables.driver.findElement(By.xpath(PasswordXpath));
		Thread.sleep(7000);
		UserPass.sendKeys(Keys.SHIFT);
		UserPass.sendKeys(PasswordFieldValue);
		

	//	
	
		
		
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PasswordNextButtonXpath)));
		ConstantVariables.driver.findElement(By.xpath(PasswordNextButtonXpath)).click();
		Thread.sleep(4000);
		ConstantVariables.driver.switchTo().window(winHandleBefore);
		
		System.out.println("page title========="+ConstantVariables.driver.getCurrentUrl());
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PortalNotificationXpath)));
		ConstantVariables.driver.findElement(By.xpath(PortalNotificationXpath)).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(NotificationSymbolXpath)));
		ConstantVariables.driver.findElement(By.xpath(NotificationSymbolXpath)).click();
		

		ArrayList<String> tabs2 = new ArrayList<String>(ConstantVariables.driver.getWindowHandles());
		ConstantVariables.driver.switchTo().window(tabs2.get(1));
		System.out.println("current URL=====" + ConstantVariables.driver.getCurrentUrl());
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MenuButtonXpath)));
		ConstantVariables.driver.findElement(By.xpath(MenuButtonXpath)).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ServiceRequestXpath)));
		ConstantVariables.driver.findElement(By.xpath(ServiceRequestXpath)).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(AccountManagementXpath)));
		ConstantVariables.driver.findElement(By.xpath(AccountManagementXpath)).click();
		
		
		ArrayList<String> tabs3 = new ArrayList<String>(ConstantVariables.driver.getWindowHandles());
		ConstantVariables.driver.switchTo().window(tabs3.get(1));
		System.out.println("current URL=====" + ConstantVariables.driver.getCurrentUrl());
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SearchWithUsernameXpath)));
		
		
		ConstantVariables.driver.findElement(By.xpath(SearchWithUsernameXpath)).sendKeys(SearchFieldValue);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SearchButtonXpath)));
		ConstantVariables.driver.findElement(By.xpath(SearchButtonXpath)).click();
		
		
		////////////////////////////////////////////////////////////////////////Code For Subscription Approval/////////////////////////////////////////////////////////
		ClickMenuButtonElement=ConstantVariables.driver.findElement(By.xpath(MenuButtonClickXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MenuButtonClickXpath)));
		ClickMenuButtonElement.click();
		
		SubscriptinButtonElement=ConstantVariables.driver.findElement(By.xpath(SubscriptionButtonXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SubscriptionButtonXpath)));
		SubscriptinButtonElement.click();
		
		SearchSubscriptionUsenameElement=ConstantVariables.driver.findElement(By.xpath(SearchSubscriptionUsernameXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SearchSubscriptionUsernameXpath)));
		SearchSubscriptionUsenameElement.sendKeys(SearchFieldValue);
		

		SubscriptionSearchButtonElement=ConstantVariables.driver.findElement(By.xpath(SubscriptionSearchButtonXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SubscriptionSearchButtonXpath)));
		SubscriptionSearchButtonElement.click();
		
		//Thread.sleep(2000);
		//SubscriptionApproveButtonElement=ConstantVariables.driver.findElement(By.xpath(SubscriptionApproveButtonXpath));
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SubscriptionApproveButtonXpath)));
		//SubscriptionApproveButtonElement.click();
		
		//Thread.sleep(2000);
		//ClickOnYesButtonWebElement=ConstantVariables.driver.findElement(By.xpath(ClickOnYesButtonXpath));
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath(ClickOnYesButtonXpath)));
		//ClickOnYesButtonWebElement.click();
		
		Thread.sleep(2000);
		MSAMenuElement=ConstantVariables.driver.findElement(By.xpath(MSAMenuXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSAMenuXpath)));
		MSAMenuElement.click();
		
		Thread.sleep(2000);
		MSAManagementElement=ConstantVariables.driver.findElement(By.xpath(MSAManagementXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSAManagementXpath)));
		MSAManagementElement.click();
		
		Thread.sleep(2000);
		MSASearchByUsernameElement=ConstantVariables.driver.findElement(By.xpath(MSASearchByUsernameXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSASearchByUsernameXpath)));
		MSASearchByUsernameElement.sendKeys(SearchFieldValue);
		
		Thread.sleep(2000);
		MSASearchButtonElement=ConstantVariables.driver.findElement(By.xpath(MSASearchButtonXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSASearchButtonXpath)));
		MSASearchButtonElement.sendKeys(SearchFieldValue);
		
		Thread.sleep(2000);
		MSASignatureElement=ConstantVariables.driver.findElement(By.xpath(MSASignatureButtonXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSASignatureButtonXpath)));
		MSASignatureElement.click();
		
		Thread.sleep(2000);
		MSASignatureCanvasElement=ConstantVariables.driver.findElement(By.xpath(MSASignatureCanvasXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSASignatureCanvasXpath)));
		MSASignatureCanvasElement.click();
		
		Thread.sleep(2000);
		MSASignButtonElement=ConstantVariables.driver.findElement(By.xpath(MSASignButtonXpath));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(MSASignButtonXpath)));
		MSASignButtonElement.click();
		
		
	}

}
