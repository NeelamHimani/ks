package Pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.collections4.map.StaticBucketMap;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;

import Test.ConstantVariables;

public class LoginWithValidUser {
	
	
	static String UsernaemXpath;
	static String PasswordXpath;
	static String loginButtonXpath;
	static String SignatureXpath;
	static String ClearbuttonXpath;
	static String SignaturebuttonXpath1;
	static String AcceptButtonXpath;
	static String PharmacyNameXpath;	
	static String SearchButttonXpath;
	static String SearchButttonXpath1;
	static String StatValueXpath;
	static String StatEnteredValueXpath;
	static String SearchButtonXpath2;
	static String AddButtonXpath;
	static String AddButtonNotAddedXpath;
	static String NextButtonXpath;
	static String RadioButtonXpath;
	static String AuthorizationCheckBOxXpath;
	static String AuthorizationNextButtonXpath;
	static String SubscribeButtonXpath;
	static String IssubscribeSelectionXpath;
	static String AddServiceButtonXpath;
	static String SubscribeNextButtonXpath;
	static String UploadButtonXpath;
	static String MSANextButtonXpath;
	static String SignAcceptButtonXpath;
	static String SkipForNowXpath;
	static String FinishbuttonXpath;
	
	
	static WebElement UsernameElement;
	static WebElement PasswordElement;
	static WebElement loginButtonElement;
	static WebElement Signatureelement;
	static WebElement clearButtonElement;
	static WebElement signatureButtonElement1;
	static WebElement acceptButtonElement;
	static WebElement pharmacyNameElement;
	static WebElement SearchbuttonElement;
	static WebElement SearchbuttonElement1;
	static WebElement StatValueElement;
	static WebElement StatEnteredValueElement;
	static WebElement SearchbuttonElement2;
	static WebElement AddButtonElement;
	static WebElement AddButtonNotAddedElement;
	static WebElement NextButtonElement;
	static WebElement RadioButtonElement;
	static WebElement AuthorizationCheckBoxElement;
	static WebElement AuthorizationNextButtonElement;
	static WebElement SubscribeButtonElement;
	static WebElement IsSubscribeElement;
	static WebElement AddServiceButtonElement;
	static WebElement SubscribeNextButtonElement;
	static WebElement UploadButtonElement;
	static WebElement MSANextButtonElement;
	static WebElement SignAcceptButtonElement;
	static WebElement SkipForNowButtonElement;
	static WebElement FinishButtonElement;
	
	public static void loginWithValidUser() throws IOException, InterruptedException {

	
		ConstantVariables.driver.get("https://dev3.kloudscript.net/");

		System.out.println("Login Page");
		String currentURL = ConstantVariables.driver.getCurrentUrl();
		System.out.println("currentURL==========" + currentURL);
		

		String pageTitle = ConstantVariables.driver.getTitle();
		System.out.println("pageTitle===============" + pageTitle);
		WebDriverWait wait = new WebDriverWait(ConstantVariables.driver, 15);
		// Code for to Redirect test2 server and active user

		// Click on KS SSO button
		KSPH_Login_Page.getfile(ConstantVariables.ORFile);

		// get sheet of ActiveuserXpath
		ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheetAt(2);
		System.out.println(ConstantVariables.excelSheet.getSheetName());

		
		UsernaemXpath = KSPH_Login_Page.getExcelData(2, 1, 2);
		PasswordXpath= KSPH_Login_Page.getExcelData(2, 2, 2);
		loginButtonXpath=KSPH_Login_Page.getExcelData(2, 3, 2);
		SignatureXpath=KSPH_Login_Page.getExcelData(2, 4, 2);
		ClearbuttonXpath=KSPH_Login_Page.getExcelData(2, 5, 2);
		SignaturebuttonXpath1=KSPH_Login_Page.getExcelData(2, 6, 2);
		AcceptButtonXpath=KSPH_Login_Page.getExcelData(2, 7, 2);
		
		PharmacyNameXpath=KSPH_Login_Page.getExcelData(2, 8, 2);
		SearchButttonXpath=KSPH_Login_Page.getExcelData(2, 9, 2);
		SearchButttonXpath1=KSPH_Login_Page.getExcelData(2, 10, 2);
		StatValueXpath=KSPH_Login_Page.getExcelData(2, 11, 2);
		StatEnteredValueXpath=KSPH_Login_Page.getExcelData(2, 12, 2);
		SearchButtonXpath2=KSPH_Login_Page.getExcelData(2, 13, 2);
		AddButtonXpath=KSPH_Login_Page.getExcelData(2, 14, 2);
		AddButtonNotAddedXpath=KSPH_Login_Page.getExcelData(2, 15, 2);
		
		NextButtonXpath=KSPH_Login_Page.getExcelData(2, 16, 2);
		
		RadioButtonXpath=KSPH_Login_Page.getExcelData(2, 17, 2);
		AuthorizationCheckBOxXpath=KSPH_Login_Page.getExcelData(2, 18, 2);
		AuthorizationNextButtonXpath=KSPH_Login_Page.getExcelData(2, 19, 2);
		SubscribeButtonXpath=KSPH_Login_Page.getExcelData(2, 20, 2);
		IssubscribeSelectionXpath=KSPH_Login_Page.getExcelData(2, 21, 2);
		AddServiceButtonXpath=KSPH_Login_Page.getExcelData(2, 22, 2);
		SubscribeNextButtonXpath=KSPH_Login_Page.getExcelData(2, 23, 2);
		//UploadButtonXpath=KSPH_Login_Page.getExcelData(4, 23, 2);
		MSANextButtonXpath=KSPH_Login_Page.getExcelData(2, 25, 2);
		SignAcceptButtonXpath=KSPH_Login_Page.getExcelData(2, 26, 2);
		SkipForNowXpath=KSPH_Login_Page.getExcelData(2, 27, 2);
		FinishbuttonXpath=KSPH_Login_Page.getExcelData(2, 28, 2);
		
		// Code For TestData File
		String filePath = ConstantVariables.TestDataFile;
		FileInputStream fis = new FileInputStream(filePath); // Your .xlsx file name along with path
		ConstantVariables.excelWorkbook = new XSSFWorkbook(fis);
		ConstantVariables.excelSheet = ConstantVariables.excelWorkbook.getSheet("LoginData");
		System.out.println("Excel sheet name====" + ConstantVariables.excelSheet.getSheetName());
		// Find number of rows in excel file
		int rowCount = ConstantVariables.excelSheet.getLastRowNum() - ConstantVariables.excelSheet.getFirstRowNum();
		// Create a loop over all the rows of excel file to read it
		int count = ConstantVariables.excelSheet.getPhysicalNumberOfRows();
		for (int i = 1; i < count; i++) {

			Row row1 = ConstantVariables.excelSheet.getRow(i);

			// ConstantVariables.test.log(LogStatus.INFO, "Organization selection completed:
			// " + SelectOrganizationXpath);
			if (row1 != null) {
				boolean cell;
				if (cell = row1.getCell(4) != null) {
					String ExcelValue = row1.getCell(4).getStringCellValue();
					System.out.println(ExcelValue);
					// ConstantVariables.test.log(LogStatus.INFO, "pharmay selection" + ExcelValue);
					UsernameElement = ConstantVariables.driver.findElement(By.xpath(UsernaemXpath));
					Actions actions = new Actions(ConstantVariables.driver);
					actions.moveToElement(ConstantVariables.driver.findElement(By.xpath(UsernaemXpath)));
					actions.click().build().perform();
					// Thread.sleep(2000);
					UsernameElement.sendKeys(ExcelValue);
				}
				if (cell = row1.getCell(5) != null) {
					String PasswordValue = row1.getCell(5).getStringCellValue();
					System.out.println(PasswordValue);
					// ConstantVariables.test.log(LogStatus.INFO, "pharmay selection" + ExcelValue);
					PasswordElement = ConstantVariables.driver.findElement(By.xpath(PasswordXpath));
					
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PasswordXpath)));
					// Thread.sleep(2000);
					PasswordElement.sendKeys(PasswordValue);				
				}				
		}
	}
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loginButtonXpath)));
		loginButtonElement=ConstantVariables.driver.findElement(By.xpath(loginButtonXpath));
		loginButtonElement.click();
		
		//Code For Signature
		Thread.sleep(3000);
		Signatureelement = ConstantVariables.driver.findElement(By.xpath(SignatureXpath));
		((JavascriptExecutor) ConstantVariables.driver).executeScript("window.scrollTo(0," + Signatureelement.getLocation().y + ")");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SignatureXpath)));	
		Signatureelement.click();
		
		Thread.sleep(3000);
		acceptButtonElement = ConstantVariables.driver.findElement(By.xpath(AcceptButtonXpath));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AcceptButtonXpath)));	
		acceptButtonElement.click();
	
	
		//Validation for pharmacy name
		int count1 = ConstantVariables.excelSheet.getPhysicalNumberOfRows();
		for (int j = 1; j < count1; j++) {

			Row row11 = ConstantVariables.excelSheet.getRow(j);

			// ConstantVariables.test.log(LogStatus.INFO, "Organization selection completed:
			// " + SelectOrganizationXpath);
			if (row11 != null) {
				boolean cell;
				
			
				if (cell = row11.getCell(6) != null) {

					DataFormatter dataFormatter = new DataFormatter();
					String value = dataFormatter.formatCellValue(row11.getCell(6));
					System.out.println("value============" + value);

					if (row11.getCell(2).getStringCellValue().equals("Pharmacy_Name_Tooltip")) {

						
						pharmacyNameElement = ConstantVariables.driver.findElement(By.xpath(PharmacyNameXpath));
						pharmacyNameElement.sendKeys(value);
						Thread.sleep(2000);

					}
					if (row11.getCell(2).getStringCellValue().equals("Pharmacy_Name_Single_Char")) {

						pharmacyNameElement.clear();
						pharmacyNameElement = ConstantVariables.driver.findElement(By.xpath(PharmacyNameXpath));
						pharmacyNameElement.sendKeys(value);

						SearchbuttonElement = ConstantVariables.driver.findElement(By.xpath(SearchButttonXpath));
						SearchbuttonElement.click();
						Thread.sleep(2000);
						
					}
					if (row11.getCell(2).getStringCellValue().equals("pharmacy_Name_With_Blank")) {

						pharmacyNameElement.clear();
						pharmacyNameElement = ConstantVariables.driver.findElement(By.xpath(PharmacyNameXpath));
						pharmacyNameElement.sendKeys(value);

						SearchbuttonElement = ConstantVariables.driver.findElement(By.xpath(SearchButttonXpath));
						SearchbuttonElement.click();
						Thread.sleep(2000);
					}
					if (row11.getCell(2).getStringCellValue().equals("pharmacy_Name_Numeric_value")) {

						pharmacyNameElement.clear();
						pharmacyNameElement = ConstantVariables.driver.findElement(By.xpath(PharmacyNameXpath));
						pharmacyNameElement.sendKeys(value);

						SearchbuttonElement = ConstantVariables.driver.findElement(By.xpath(SearchButttonXpath));
						SearchbuttonElement.click();
						Thread.sleep(4000);
					}
					if (row11.getCell(2).getStringCellValue().equals("pharmacy_Name_With_Correct_Value")) {

						pharmacyNameElement.clear();
						pharmacyNameElement = ConstantVariables.driver.findElement(By.xpath(PharmacyNameXpath));
						pharmacyNameElement.sendKeys(value);

						SearchbuttonElement = ConstantVariables.driver.findElement(By.xpath(SearchButttonXpath));
						SearchbuttonElement.click();
						Thread.sleep(4000);
					}
				
					
				}
				if (cell = row11.getCell(7) !=null) {

					
					DataFormatter dataFormatter = new DataFormatter();
					String stateValue = dataFormatter.formatCellValue(row11.getCell(7));
					System.out.println("value============" + stateValue);
					
					  if (row11.getCell(2).getStringCellValue().equals("State_Name_Blank")) {
					
					  SearchbuttonElement1 =ConstantVariables.driver.findElement(By.xpath(SearchButttonXpath1));
					  SearchbuttonElement1.click(); 
					  Thread.sleep(4000);
					  
					  StatValueElement=ConstantVariables.driver.findElement(By.xpath(StatValueXpath));
					  StatValueElement.click();
					  Thread.sleep(3000);
					  
					  
					  }
					if (row11.getCell(2).getStringCellValue().equals("State_Name_Valid_Value")) {
						 Thread.sleep(3000);
						StatEnteredValueElement = ConstantVariables.driver.findElement(By.xpath(StatEnteredValueXpath));
						Actions actions = new Actions(ConstantVariables.driver);
						actions.moveToElement(ConstantVariables.driver.findElement(By.xpath(StatEnteredValueXpath)));
						actions.click().build().perform();

					
					}
					 

				}
				if(cell=row11.getCell(8)!=null) {
					DataFormatter dataFormatter = new DataFormatter();
					String AddLocationButtonValue = dataFormatter.formatCellValue(row11.getCell(8));
					System.out.println("value============" + AddLocationButtonValue);
					
					  if (row11.getCell(2).getStringCellValue().equals("Add_Location")) {
							Thread.sleep(5000);
							AddButtonElement=ConstantVariables.driver.findElement(By.xpath(AddButtonXpath));
							AddButtonElement.click();
					  }
					  if (row11.getCell(2).getStringCellValue().equals("Add_Location_Valid")) {
							Thread.sleep(5000);
							AddButtonNotAddedElement=ConstantVariables.driver.findElement(By.xpath(AddButtonNotAddedXpath));
							AddButtonNotAddedElement.click();
							Thread.sleep(5000);
					  }
				}
			}

		}
	
		 Thread.sleep(3000);
		NextButtonElement=ConstantVariables.driver.findElement(By.xpath(NextButtonXpath));
		NextButtonElement.click();
		
		Thread.sleep(3000);
		
		
		/////////////////////////////////////////////////////////////Automation Script For Authorization tab///////////////////////////////////////////////////////////////////
		//Select any one radio button
		List RadioButton = ConstantVariables.driver.findElements(By.xpath(RadioButtonXpath));
		// selecting the Radio buttons by Name
		int Size = RadioButton.size(); // finding the number of Radio buttons
		for (int i = 0; i < Size; i++) // starts the loop from first Radio button to the last one
		{
			String val = ((WebElement) RadioButton.get(i)).getAttribute("value");
			// Radio button name stored to the string variable, using 'Value' attribute
			if (val.equalsIgnoreCase("yes")) // equalsIgnoreCase is ignore case(upper/lower)
			{ // selecting the Radio button if its value is same as that we are looking for
				Thread.sleep(3000);
				((WebElement) RadioButton.get(i)).click();
				break;
			}
		}
		Thread.sleep(3000);
		//Code for CheckBox
		AuthorizationCheckBoxElement = ConstantVariables.driver.findElement(By.xpath(AuthorizationCheckBOxXpath));
		if(!AuthorizationCheckBoxElement.isSelected()){
			AuthorizationCheckBoxElement.click();
		}
		
		 Thread.sleep(3000);
		
		//Code For Authorization Next Button
		AuthorizationNextButtonElement=ConstantVariables.driver.findElement(By.xpath(AuthorizationNextButtonXpath));
		AuthorizationNextButtonElement.click();
		Thread.sleep(3000);
	
		//////////////////////////////////////////////////////Automation Script for Subscribe in Subscription tab\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
		SubscribeButtonElement = ConstantVariables.driver.findElement(By.xpath(SubscribeButtonXpath));
		SubscribeButtonElement.click();

		Thread.sleep(3000);
		IsSubscribeElement = ConstantVariables.driver.findElement(By.xpath(IssubscribeSelectionXpath));
		((JavascriptExecutor) ConstantVariables.driver).executeScript("window.scrollTo(0," + IsSubscribeElement.getLocation().y + ")");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(IssubscribeSelectionXpath)));	
		IsSubscribeElement.click();
		
		Thread.sleep(2000);
		AddServiceButtonElement = ConstantVariables.driver.findElement(By.xpath(AddServiceButtonXpath));
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AddServiceButtonXpath)));	
		AddServiceButtonElement.click();
		
		Thread.sleep(2000);
		SubscribeNextButtonElement=ConstantVariables.driver.findElement(By.xpath(SubscribeNextButtonXpath));
		Thread.sleep(2000);
		((JavascriptExecutor) ConstantVariables.driver).executeScript("window.scrollTo(0," + SubscribeNextButtonElement.getLocation().y + ")");
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SubscribeNextButtonXpath)));	
		SubscribeNextButtonElement.click();
		
		//////////////////////////////////////////////////////////Automation Script for MSA/////////////////////////////////////////////////////////////////////////////////////////////
		
		/*
		 * UploadButtonElement =
		 * ConstantVariables.driver.findElement(By.xpath(UploadButtonXpath));
		 * ((JavascriptExecutor)
		 * ConstantVariables.driver).executeScript("window.scrollTo(0," +
		 * UploadButtonElement.getLocation().y + ")");  Thread.sleep(8000); //
		 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
		 * UploadButtonXpath))); // UploadButtonElement.sendKeys(
		 * "D:\\15-07-2020\\KSPH_Automation_Script\\download.png");
		 */		

		Thread.sleep(8000);
		MSANextButtonElement = ConstantVariables.driver.findElement(By.xpath(MSANextButtonXpath));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(MSANextButtonXpath)));	
		MSANextButtonElement.click();
		
		SignAcceptButtonElement = ConstantVariables.driver.findElement(By.xpath(SignAcceptButtonXpath));
		Thread.sleep(8000);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SignAcceptButtonXpath)));	
		SignAcceptButtonElement.click();

		Thread.sleep(4000);
		//////////////////////////////////////////////////////////Code For Payment Tab/////////////////////////////////////////////////////////////////////////////////////////////
		SkipForNowButtonElement = ConstantVariables.driver.findElement(By.xpath(SkipForNowXpath));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(SkipForNowXpath)));	
		SkipForNowButtonElement.click();
		
		Thread.sleep(3000);
		FinishButtonElement = ConstantVariables.driver.findElement(By.xpath(FinishbuttonXpath));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(FinishbuttonXpath)));
		FinishButtonElement.click();
	
	}
}

